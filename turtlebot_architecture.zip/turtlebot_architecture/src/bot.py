#!/usr/bin/env python3
import random
import math
import copy
import time
import rospy
from geometry_msgs.msg import Twist, Pose  # Import msg data types to be used
from std_msgs.msg import String, Int32, Float64MultiArray
from nav_msgs.msg import Odometry
import numpy as np
from tf.transformations import euler_from_quaternion
import paho.mqtt.client as mqtt
import json

class TurtlebotControl:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('Flags', anonymous=True)

        # Define the rate at which to publish messages
        self.rate = rospy.Rate(10)  # 10hz

        # MQTT setup
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_message = self.on_message
        self.ManipulatorRecive=""
        # Connect to the MQTT broker
        self.mqtt_client.connect("localhost", 1883, 60)  # Ensure this is the correct broker address
        self.mqtt_client.loop_start()

        # ROS Publisher and Subscriber
        self.pub = rospy.Publisher('/Goal', Float64MultiArray, queue_size=1)
        self.pub2= rospy.Publisher('/MQTT_msg', String, queue_size=1)
        self.sub = rospy.Subscriber('/odom', Odometry, self.callback)
        self.sub2= rospy.Subscriber('/Gripping_Status', String, self.callbackgripper)

        self.current_pos = [0, 0, 0]
        self.tolerance = 0.03
        self.theta_tolerance = 3 * math.pi / 180

        self.goals = {
            "path1":[[0.0,0,90*math.pi/180],[0.0,1.05,180*math.pi/180],[-1.42,1.05,-90*math.pi/180],[-1.42,1.05,0*math.pi/180],[0.32,1.05,90*math.pi/180],[0.32,1.65,0*math.pi/180],[1.12, 1.65, 0*math.pi/180], [1.12,1.65,180*math.pi/180],[0.32, 1.65, -90*math.pi/180], [0.32, 0, 180*math.pi/180], [0,0,0*math.pi/180]],
            "lane1 beginning":[0.32, 1.05, 180 * math.pi / 180],
            "lane1 end":[0.32, 1.05, 180 * math.pi / 180],
            "lane2 beginning":[0.32, 1.05, 180 * math.pi / 180],
            "lane2 end":[0.32, 1.05, 180 * math.pi / 180],
            "get raw material": [0.32, 0, 90 * math.pi / 180],
            "go to factory": [0.32, 1.05, 180 * math.pi / 180],
            "go home": [0, 0, 0 * math.pi / 180]
        }

        self.current_goal = [-1, -1, -1]
        self.flag = False
        self.flag_initial = 0

    def on_connect(self, client, userdata, flags, rc):
        rospy.loginfo("Connected to MQTT broker with result code " + str(rc))
        client.subscribe("tb1bot/command")

    def on_message(self, client, userdata, msg):
        rospy.loginfo(f"Received MQTT message on topic {msg.topic}: {msg.payload}")
        try:
            data = msg.payload.decode()
            if not data:
                raise ValueError("Empty payload received")
            if msg.topic == "tb1bot/command":
                self.process_bot_command(data)
                self.send_feedback("Received command: " + data)
        except json.JSONDecodeError as e:
            rospy.logerr(f"JSON decoding failed: {e}")
            rospy.logerr(f"Payload received: {msg.payload}")
        except ValueError as e:
            rospy.logerr(f"Value error: {e}")
            rospy.logerr(f"Payload received: {msg.payload}")
        except Exception as e:
            rospy.logerr(f"Unexpected error: {e}")
            rospy.logerr(f"Payload received: {msg.payload}")

    def process_bot_command(self, data):
        # Process the bot command received from MQTT
        try:
            command = json.loads(data)["command"]
            rospy.loginfo(f"Received command: {command}")

            # Set the current goal based on the command
            if command in self.goals:
                self.current_goal = self.goals[command]
                self.flag = True  # Indicate that a new goal has been set
            else:
                rospy.logwarn(f"Unknown command received: {command}")

            self.send_feedback(f"Executing command: {command}")
        except json.JSONDecodeError as e:
            rospy.logerr(f"JSON decoding failed in process_bot_command: {e}")
            rospy.logerr(f"Data received: {data}")
        except Exception as e:
            rospy.logerr(f"Unexpected error in process_bot_command: {e}")
            rospy.logerr(f"Data received: {data}")

    def send_feedback(self, message):
        try:
            rospy.loginfo(f"Sending feedback: {message}")
            self.mqtt_client.publish('turtlebot1/feedback', json.dumps({"feedback": message}))
        except Exception as e:
            rospy.logerr(f"Unexpected error in send_feedback: {e}")
            rospy.logerr(f"Message received: {message}")

    def callback(self, data):
        self.flag_initial = 1
        msg = data
        self.current_pos[0] = round(msg.pose.pose.position.x, 4)
        self.current_pos[1] = round(msg.pose.pose.position.y, 4)
        orientation_q = msg.pose.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        roll, pitch, yaw = euler_from_quaternion(orientation_list)
        self.current_pos[2] = round(yaw, 4)
    def callbackgripper(self,data):
        self.ManipulatorRecive = data.data
    

    def distanceto_goal(self):
        return self.distanceto_point(self.current_goal)

    def DistancetoPoint(self, point):
        dx = point[0] - self.current_pos[0]
        dy = point[1] - self.current_pos[1]
        dtheta = point[2] - self.current_pos[2]
        return [dx, dy, dtheta]

    def DidIconverge(self,error):
        global tolerance
        global thetaTolerance
        if error[0]<tolerance and error[1]<tolerance and error[2]<thetaTolerance:
            return True
        return False

    def run(self):
        global tolerance
        global thetaTolerance
        Current_pos=[0,0,0]
        tolerance=0.7
        thetaTolerance=3*math.pi/180

        data_to_send = Float64MultiArray()
        i=0
        j=0
        #TB1 goals=[[0.32,0,90*math.pi/180],[0.32,1.9,0*math.pi/180],[1.12,1.9,0*math.pi/180],[1.12,1.9,180*math.pi/180],[-1.08,1.9,180*math.pi/180],[-1.08,1.9,-90*math.pi/180],[-1.08, 1.9, 0*math.pi/180],[0.32,1.9, -90*math.pi/180 ],[0.32,0,180*math.pi/180],[0,0,0*math.pi/180]]
        goals=[[0.0,0,90*math.pi/180],[0.0,1.05,180*math.pi/180],[-1.42,1.05,-90*math.pi/180],[-1.42,1.05,0*math.pi/180],[0.32,1.05,90*math.pi/180],[0.32,1.65,0*math.pi/180],[1.12, 1.65, 0*math.pi/180], [1.12,1.65,180*math.pi/180],[0.32, 1.65, -90*math.pi/180], [0.32, 0, 180*math.pi/180], [0,0,0*math.pi/180]]
        
        PlacePosition=[0,0,0]
        Currentgoal=goals[i]
        GrippingPosition=3
        ReleasePosition=7
        C1=True
        C2=True
        manipulatormessage=String()
        while(1 and not rospy.is_shutdown()):
            while not(self.flag and not rospy.is_shutdown()):
                continue

            error = np.abs(self.DistancetoPoint(Currentgoal))
            if i<len(goals)-1 and self.DidIconverge(error):
                #print("wesellttt no'taa x")
                self.send_feedback("Reached a point")
                i=i+1
            if (i==GrippingPosition) and C1:
                C1 = False
                manipulatormessage.data="Grip_Now"
                print("publishing")
                self.pub2.publish(manipulatormessage)
                time.sleep(1)
                while(self.ManipulatorRecive !="Gripped" and not rospy.is_shutdown()):
                    manipulatormessage.data=""
                    self.pub2.publish(manipulatormessage)
            
            if (i==ReleasePosition and C2):
                C2=False
                time.sleep(1)
                manipulatormessage.data="Release"
                self.pub2.publish(manipulatormessage)
                time.sleep(1)
                while(self.ManipulatorRecive !="Released" and not rospy.is_shutdown()):
                    manipulatormessage.data=""
                    self.pub2.publish(manipulatormessage)

            Currentgoal=goals[i]
            data_to_send.data = Currentgoal
            print("Goal,Point",data_to_send.data)
            self.pub.publish(data_to_send)
            #print(Current_pos)
            #print(Distance)
            self.rate.sleep()

if __name__ == "__main__":
    node = TurtlebotControl()
    node.run()