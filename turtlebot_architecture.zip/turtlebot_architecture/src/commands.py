#!/usr/bin/env python3

import rospy
import paho.mqtt.client as mqtt
import json

class TurtleBot3MQTTReceiver:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('commands', anonymous=True)

        # MQTT setup
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_message = self.on_message

        # Connect to the MQTT broker
        self.mqtt_client.connect("localhost", 1883, 60)  # Ensure this is the correct broker address

        # Start the MQTT client loop
        self.mqtt_client.loop_start()

        # Command sequence
        self.commands = ["get raw material", "grip", "go to factory", "dropoff"]
        self.current_command_index = 0

    def on_connect(self, client, userdata, flags, rc):
        rospy.loginfo("Connected to MQTT broker with result code " + str(rc))
        # Subscribe to the desired topics
        client.subscribe("factory/flags")
        client.subscribe("turtlebot1/feedback")
        client.subscribe("tb1bot/feedback")
        client.subscribe("turtlebot1/grip_feedback")

    def on_message(self, client, userdata, msg):
        rospy.loginfo(f"Received MQTT message on topic {msg.topic}: {msg.payload}")
        try:
            data = msg.payload.decode()
            if msg.topic == "factory/flags":
                flag = int(data)
                self.process_flag(flag)
            elif msg.topic in ["turtlebot1/feedback", "tb1bot/feedback", "turtlebot1/grip_feedback"]:
                self.handle_feedback(data)
        except Exception as e:
            rospy.logerr(f"Failed to parse MQTT message: {e}")

    def process_flag(self, flag):
        rospy.loginfo(f"Processing flag: {flag}")
        if flag == 1:
            self.current_command_index = 0
            self.send_next_command()

    def send_next_command(self):
        if self.current_command_index < len(self.commands):
            command = self.commands[self.current_command_index]
            if command in ["grip", "dropoff"]:
                self.send_to_gripper(command)
            else:
                self.send_to_turtlebots(command)
        else:
            rospy.loginfo("All commands have been executed.")

    def send_to_turtlebots(self, command):
        rospy.loginfo(f"Sending command to Bot: {command}")
        self.mqtt_client.publish('tb1bot/command', json.dumps({"command": command}))

    def send_to_gripper(self, command):
        rospy.loginfo(f"Sending command to Gripper: {command}")
        self.mqtt_client.publish('turtlebot1/grip', json.dumps({"command": command}))

    def handle_feedback(self, feedback):
        rospy.loginfo(f"Received feedback: {feedback}")
        self.current_command_index += 1
        self.send_next_command()

if __name__ == '__main__':
    try:
        receiver = TurtleBot3MQTTReceiver()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
