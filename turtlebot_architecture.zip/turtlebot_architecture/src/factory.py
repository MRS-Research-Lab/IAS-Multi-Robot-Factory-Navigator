#!/usr/bin/env python3

import json
import rospy
import paho.mqtt.client as mqtt

class TurtleBot3MQTTPublisher:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('Flags', anonymous=True)

        # Define the rate at which to publish messages
        self.rate = rospy.Rate(10)  # 10hz

        # MQTT setup
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_message = self.on_message

        # Connect to the MQTT broker
        self.mqtt_client.connect("localhost", 1883, 60)  # Ensure this is the correct broker address

        # Start the MQTT client loop
        self.mqtt_client.loop_start()

        # Command sequence
        self.commands = {
            0: "halt",
            1: "get raw material"
        }
        self.waiting_for_response = False

    def on_connect(self, client, userdata, flags, rc):
        rospy.loginfo("Connected to MQTT broker with result code " + str(rc))
        client.subscribe("factory/flags")
        # client.subscribe("turtlebot3/response")

    def on_message(self, client, userdata, msg):
        try:
            data = msg.payload.decode()
            if msg.topic == "turtlebot3/response":
                self.handle_response(data)
            elif msg.topic == "factory/flags":
                flag = int(data)
                self.handle_flag(flag)
        except Exception as e:
            rospy.logerr(f"Failed to parse MQTT message: {e}")

    def handle_flag(self, flag):
        command = self.commands.get(flag, "halt")
        rospy.loginfo(f"Handling flag: {flag}, sending command: {command}")
        if command == "halt":
            self.mqtt_client.publish("commands", json.dumps({"command": "halt"}))
        elif command == "get raw material":
            self.mqtt_client.publish("commands", json.dumps({"command": "get raw material"}))
        self.waiting_for_response = True

    def handle_response(self, response):
        rospy.loginfo(f"Response from TurtleBot3: {response}")
        self.waiting_for_response = False

if __name__ == '__main__':
    try:
        controller = TurtleBot3MQTTPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass